 **Windows 10 OS**

- No additional Drivers are needed to be installed under Windows 10
  Windows has already a Default Driver that will allow Radio to operating with under CPS Utility