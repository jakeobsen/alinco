 **Windows 10 OS**

- No additional Drivers are needed to be installed under Windows 10
  Windows has already a built-in Default Driver that will allow Radio 
  to operating with under CPS Utility 



**Windows 7/8/Vista OS**

- Important - Windows 7/8/Vista confirm your OS 32 or 64bit version.
- 32bit OS, open the x68 folder and install "USB Virtual Com Port Driver.exe"
- 64bit OS, open the x64 folder and install "USB Virtual Com Port Driver.exe" 